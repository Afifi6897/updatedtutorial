export default {

	templete: '<h1>hello worlds huhuh<h1>'


};