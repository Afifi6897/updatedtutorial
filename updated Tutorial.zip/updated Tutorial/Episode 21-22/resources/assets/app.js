import Vue from 'vue';

import axios from 'axios';

import Form from './core/Form';

import Eexample from'./components/Eexample';

window.axios = axios;
window.Form = Form;


new Vue({
    el: '#app',

    components:{

    Eexample

    },

    data: {
        form: new Form({
            name: '',
            description: ''
        })
    },

    methods: {
        onSubmit() {
            this.form.post('/projects')
                .then(response => alert('Wahoo!'));
        }
    }
});
