import './bootstrap';
import router from './routes';









 new Vue({

	el: '#app',


	router


});