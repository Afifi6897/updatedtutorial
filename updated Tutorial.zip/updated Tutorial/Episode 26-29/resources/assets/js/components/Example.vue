<template>
 <div class="container">
 	<div class="columns">
 		<div class="column">
 			<div class="message" v-for ="status for statuses">
 				<div>

 					<p>

 						{{status.user.name}}said...


 					</p>

 					<p>
 						{{ status.created_at | ago | capitallize }}
 					</p>



 				</div>



 				<div class="message-body" v-text="status.body">

 					
 				</div>

 				<add-to-stream @completed="addStatus"></add-to-stream>

 			</div>
 		</div>
 	</div>
 </div>
</template>


<script>
	
	import status from '../models/Status';
	import moment from 'moment';
	import AddtoStream from '../component/AddtoStream.vue';




	export default(){


		components:{ AddtoStream},

		data(){


		statuses:[]


		},

		filter:{

			ago(date){

			return moment(date).fromNow();
			}

			capitalize(value){

				return value.toUpperCase();
			}
		},

		created(){
		
			Status.all(statuses => this.statuses = statuses);
				
		},

		methods:{


		addStatus(status){

			this.sttuses.unshift(status);

			alert('Your status has been added');

			window.scrollTo(0,0);
		}

		}

	}

</script>