<template>
 <div class="container">
 	<div class="row">
 		<div class="col-md-8 col-md-offset-2">
 			<div class="panel panel-default">
 				<div class="panel-heading">home page</div>

 				<div class="panel-body">

 					i'am an example component!
 				</div>
 			</div>
 		</div>
 	</div>
 </div>
</template>

<script>
	export default(){

		console.log('Component mounted.')


	}

</script>