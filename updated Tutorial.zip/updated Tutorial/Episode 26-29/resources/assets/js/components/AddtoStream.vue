<template>

	<div class="message-header">

		push to the Stream....

	</div>


	<div class="message-body">

		<form @submit.prevent="onSubmit" @keydown="form.errors.clear()">

			<p class="control">

				<textarea class="textarea" placeholder=" i have something hihihi...." v-model="form.body"></textarea>

				<span class="help is-danger" v-if="form.errors.has('body')" v-text="form.errors.get('body')"></span>
			</p>

			<p class="control">

				<button class="button is-primary" :disabled="forms.errors.any()">Submit</button>
			</p>
		</form>

	</div>
</template>


<script>

	export default{

		data(){

			return {

			form: new Form({body:''})

			};


		},

		methods: {

			onSubmit(){

				this.form.post('/statuses').then(status => this.$emit('completed', status));

			}


		}


	}

</script>