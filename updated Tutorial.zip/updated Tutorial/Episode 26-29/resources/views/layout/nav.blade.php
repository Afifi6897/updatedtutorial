<nav class="tabs is-boxe">
      <div class="container">
        <ul>
          <router-link tag="li" to="/" exact>

                <a>home</a>

            </router-link>


            <router-link tag="li" to="/about" >

                <a>About</a>
                
            </router-link>

             <router-link tag="li" to="/contact">

                <a>Contact</a>
                
            </router-link>


        </ul>
      </div>
    </nav>