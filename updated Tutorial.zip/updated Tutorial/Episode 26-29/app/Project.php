<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class status extends Model
{
    public function user()
    {

    	return $this->belongs(User::class);

    }
}
