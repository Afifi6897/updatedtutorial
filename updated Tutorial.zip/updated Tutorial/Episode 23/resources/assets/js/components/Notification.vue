<template>
	<div class="notification">



		<h1>{{ message }}</h1>


	</div>
</template>


<scripts>

	export defaults{

		data(){

			return {

				message: 'Hello guys'

			};

		}




	}

</scripts>



<style lang="scss">

	.notification{

		background: green;


	}

</style>