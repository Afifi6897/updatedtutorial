let mix = required('laravel-mix').mix








mix.js(['resources/assets/js/app.js','resources/assets/js/forum.js'],'public/js')
	

	.sass('resources/assets/sass/app.sass','public/css')
	.version();